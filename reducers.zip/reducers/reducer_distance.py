#!/usr/bin/env python3
"""Reducer for analysis (f) Distance-Based Fare Analysis.
Input:  category<TAB>fare,distance,total,1
Output: category<TAB>count,avg_fare,avg_distance,avg_total,total_revenue
"""
import sys


def emit(key, fare, dist, total, cnt):
    print(f"{key}\t{cnt}\t{fare / cnt:.2f}\t{dist / cnt:.2f}\t{total / cnt:.2f}\t{total:.2f}")


current_key = None
fare_sum = dist_sum = total_sum = 0.0
cnt = 0

for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    parts = line.split("\t")
    if len(parts) != 5:
        continue
    key, fare, dist, total, c = parts
    try:
        fare, dist, total, c = float(fare), float(dist), float(total), int(c)
    except ValueError:
        continue
    if current_key == key:
        fare_sum += fare
        dist_sum += dist
        total_sum += total
        cnt += c
    else:
        if current_key is not None:
            emit(current_key, fare_sum, dist_sum, total_sum, cnt)
        current_key, fare_sum, dist_sum, total_sum, cnt = key, fare, dist, total, c

if current_key is not None:
    emit(current_key, fare_sum, dist_sum, total_sum, cnt)
