#!/usr/bin/env python3
"""Reducer for analysis (d) Revenue by Pickup Location.
Input:  PULocationID<TAB>fare,tip,total,distance,1
Output: PULocationID<TAB>count,fare_sum,tip_sum,revenue_sum,avg_fare,avg_distance
"""
import sys


def emit(key, fare, tip, total, dist, cnt):
    avg_fare = fare / cnt if cnt else 0
    avg_dist = dist / cnt if cnt else 0
    print(f"{key}\t{cnt}\t{fare:.2f}\t{tip:.2f}\t{total:.2f}\t{avg_fare:.2f}\t{avg_dist:.2f}")


current_key = None
fare_sum = tip_sum = total_sum = dist_sum = 0.0
cnt = 0

for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    parts = line.split("\t")
    if len(parts) != 6:
        continue
    key, fare, tip, total, dist, c = parts
    try:
        fare, tip, total, dist, c = float(fare), float(tip), float(total), float(dist), int(c)
    except ValueError:
        continue
    if current_key == key:
        fare_sum += fare
        tip_sum += tip
        total_sum += total
        dist_sum += dist
        cnt += c
    else:
        if current_key is not None:
            emit(current_key, fare_sum, tip_sum, total_sum, dist_sum, cnt)
        current_key, fare_sum, tip_sum, total_sum, dist_sum, cnt = key, fare, tip, total, dist, c

if current_key is not None:
    emit(current_key, fare_sum, tip_sum, total_sum, dist_sum, cnt)
