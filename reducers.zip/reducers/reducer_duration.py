#!/usr/bin/env python3
"""Reducer for analysis (h) Trip Duration Analysis.
Input:  duration_category<TAB>fare,distance,tip,1
Output: duration_category<TAB>count,avg_fare,avg_distance,avg_tip
"""
import sys


def emit(key, fare, dist, tip, cnt):
    print(f"{key}\t{cnt}\t{fare / cnt:.2f}\t{dist / cnt:.2f}\t{tip / cnt:.2f}")


current_key = None
fare_sum = dist_sum = tip_sum = 0.0
cnt = 0

for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    parts = line.split("\t")
    if len(parts) != 5:
        continue
    key, fare, dist, tip, c = parts
    try:
        fare, dist, tip, c = float(fare), float(dist), float(tip), int(c)
    except ValueError:
        continue
    if current_key == key:
        fare_sum += fare
        dist_sum += dist
        tip_sum += tip
        cnt += c
    else:
        if current_key is not None:
            emit(current_key, fare_sum, dist_sum, tip_sum, cnt)
        current_key, fare_sum, dist_sum, tip_sum, cnt = key, fare, dist, tip, c

if current_key is not None:
    emit(current_key, fare_sum, dist_sum, tip_sum, cnt)
