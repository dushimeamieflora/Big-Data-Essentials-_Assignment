import sys

results = []

for line in sys.stdin:
    line = line.strip()

    if not line:
        continue

    parts = line.split("\t")

    if len(parts) >= 2:
        try:
            zone = parts[0]
            revenue = float(parts[1])
            results.append((zone, revenue))
        except ValueError:
            continue

# Sort by revenue from highest to lowest
results.sort(key=lambda x: x[1], reverse=True)

# Print top 10
for zone, revenue in results[:10]:
    print(f"{zone}\t{revenue:.2f}")