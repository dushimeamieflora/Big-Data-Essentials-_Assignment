#!/usr/bin/env python3
"""
Generic Stage-2 reducer: receives ALL Stage-1 output rows (because
mapper_topn.py gave every row the same key "ALL", so a single reducer
-- run with -numReduceTasks 1 -- gets the entire dataset), sorts them by
one numeric field, and prints only the top/bottom N.

This is the compulsory two-stage MapReduce pipeline (Section 9):
  Stage 1: reducer_revenue.py -> PULocationID  count  fare  tip  revenue  avg_fare  avg_dist
  Stage 2: this script -> Top 10 zones by revenue (field index 3, i.e. the
           4th column counting the key as column 0)

It is reused for:
  - Top10 / Bottom10 pickup zones (Stage-1 output: zone<TAB>count)
  - Top20 routes by count and by revenue (Stage-1 output: route<TAB>count,fare_sum,revenue_sum)

Usage (arguments come after the script name on the -mapper/-reducer line):
    python3 reducer_topn.py <field_index> <top_n> <asc|desc>

field_index is 0-based over the Stage-1 OUTPUT columns, where column 0
is the key itself (zone/category/route id) and column 1, 2, ... are the
tab-separated value columns that followed it.
"""
import sys

field_index = int(sys.argv[1])
top_n = int(sys.argv[2])
order = sys.argv[3] if len(sys.argv) > 3 else "desc"

rows = []
for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    _, rest = line.split("\t", 1)          # drop the constant "ALL" key
    fields = rest.split("\t")
    try:
        sort_val = float(fields[field_index])
    except (ValueError, IndexError):
        continue
    rows.append((sort_val, rest))

rows.sort(key=lambda x: x[0], reverse=(order == "desc"))

for sort_val, rest in rows[:top_n]:
    print(rest)
