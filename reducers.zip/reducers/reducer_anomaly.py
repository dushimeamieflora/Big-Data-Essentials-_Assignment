#!/usr/bin/env python3
"""Generic sum reducer used for analysis (i) Anomaly Detection (counts per anomaly type, plus ANOMALY_TOTAL vs VALID_TOTAL)."""
import sys

current_key, current_count = None, 0

for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    key, value = line.split("\t", 1)
    try:
        value = int(value)
    except ValueError:
        continue
    if current_key == key:
        current_count += value
    else:
        if current_key is not None:
            print(f"{current_key}\t{current_count}")
        current_key, current_count = key, value

if current_key is not None:
    print(f"{current_key}\t{current_count}")
