#!/usr/bin/env python3
"""Reducer for analysis (g) Busiest Pickup-Dropoff Routes.
Input:  PU-DO<TAB>fare,total,1
Output: PU-DO<TAB>count,fare_sum,revenue_sum
(Feed this output into mapper_topn.py / reducer_topn.py twice: once
sorting on field index 1 [count] for Top20 by trips, once on field
index 2 [revenue_sum] for Top20 by revenue.)
"""
import sys


def emit(key, fare, total, cnt):
    print(f"{key}\t{cnt}\t{fare:.2f}\t{total:.2f}")


current_key = None
fare_sum = total_sum = 0.0
cnt = 0

for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    parts = line.split("\t")
    if len(parts) != 4:
        continue
    key, fare, total, c = parts
    try:
        fare, total, c = float(fare), float(total), int(c)
    except ValueError:
        continue
    if current_key == key:
        fare_sum += fare
        total_sum += total
        cnt += c
    else:
        if current_key is not None:
            emit(current_key, fare_sum, total_sum, cnt)
        current_key, fare_sum, total_sum, cnt = key, fare, total, c

if current_key is not None:
    emit(current_key, fare_sum, total_sum, cnt)
