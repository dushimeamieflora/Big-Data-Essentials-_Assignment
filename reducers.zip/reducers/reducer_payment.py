#!/usr/bin/env python3
"""Reducer for analysis (e) Payment Method Analysis.
Input:  payment_name<TAB>fare,tip,total,1
Output: payment_name<TAB>count,total_revenue,avg_fare,avg_tip
"""
import sys


def emit(key, fare, tip, total, cnt):
    avg_fare = fare / cnt if cnt else 0
    avg_tip = tip / cnt if cnt else 0
    print(f"{key}\t{cnt}\t{total:.2f}\t{avg_fare:.2f}\t{avg_tip:.2f}")


current_key = None
fare_sum = tip_sum = total_sum = 0.0
cnt = 0

for line in sys.stdin:
    line = line.strip()
    if not line:
        continue
    parts = line.split("\t")
    if len(parts) != 5:
        continue
    key, fare, tip, total, c = parts
    try:
        fare, tip, total, c = float(fare), float(tip), float(total), int(c)
    except ValueError:
        continue
    if current_key == key:
        fare_sum += fare
        tip_sum += tip
        total_sum += total
        cnt += c
    else:
        if current_key is not None:
            emit(current_key, fare_sum, tip_sum, total_sum, cnt)
        current_key, fare_sum, tip_sum, total_sum, cnt = key, fare, tip, total, c

if current_key is not None:
    emit(current_key, fare_sum, tip_sum, total_sum, cnt)
