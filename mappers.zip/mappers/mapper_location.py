#!/usr/bin/env python3
"""Mapper for analysis (c) Pickup Location Analysis. Emits: PULocationID<TAB>1"""
import sys, csv

PU = 7  # PULocationID column index

reader = csv.reader(sys.stdin)
for row in reader:
    if not row or row[0] == "VendorID":
        continue
    try:
        pu = int(float(row[PU]))
        print(f"{pu}\t1")
    except (ValueError, IndexError):
        continue
