#!/usr/bin/env python3
"""Mapper for analysis (a) Hourly Taxi Demand. Emits: hour<TAB>1"""
import sys, csv
from datetime import datetime

PICKUP_DT = 1  # tpep_pickup_datetime column index

reader = csv.reader(sys.stdin)
for row in reader:
    if not row or row[0] == "VendorID":
        continue
    try:
        dt = datetime.strptime(row[PICKUP_DT][:19], "%Y-%m-%d %H:%M:%S")
        print(f"{dt.hour:02d}\t1")
    except (ValueError, IndexError):
        continue
