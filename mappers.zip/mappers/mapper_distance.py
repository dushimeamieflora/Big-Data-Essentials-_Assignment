#!/usr/bin/env python3
"""Mapper for analysis (f) Distance-Based Fare Analysis.
Emits: category<TAB>fare,distance,total,1
"""
import sys, csv

DIST, FARE, TOTAL = 4, 10, 16

def bucket(d):
    if d <= 2:
        return "0-2"
    if d <= 5:
        return "2-5"
    if d <= 10:
        return "5-10"
    if d <= 20:
        return "10-20"
    return "20+"

reader = csv.reader(sys.stdin)
for row in reader:
    if not row or row[0] == "VendorID":
        continue
    try:
        dist = float(row[DIST])
        fare = float(row[FARE])
        total = float(row[TOTAL])
        print(f"{bucket(dist)}\t{fare}\t{dist}\t{total}\t1")
    except (ValueError, IndexError):
        continue
