import sys

for line in sys.stdin:
    parts = line.split()

    if len(parts) >= 5:
        location = parts[0]
        revenue = parts[4]

        print(location + "\t" + revenue)