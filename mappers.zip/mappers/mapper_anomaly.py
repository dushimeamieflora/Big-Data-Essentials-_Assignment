#!/usr/bin/env python3
"""Mapper for analysis (i) Anomaly Detection.
Emits one line per triggered rule, e.g.: invalid_distance<TAB>1
Also emits ANOMALY_TOTAL / VALID_TOTAL counters so the reducer (and your
report) can compute what percentage of records are anomalous.
"""
import sys, csv
from datetime import datetime

PICKUP, DROPOFF, PAX, DIST, FARE, TOTAL = 1, 2, 3, 4, 10, 16

reader = csv.reader(sys.stdin)
for row in reader:
    if not row or row[0] == "VendorID":
        continue
    reasons = []
    try:
        pax = float(row[PAX])
        dist = float(row[DIST])
        fare = float(row[FARE])
        total = float(row[TOTAL])
        pu_dt = datetime.strptime(row[PICKUP][:19], "%Y-%m-%d %H:%M:%S")
        do_dt = datetime.strptime(row[DROPOFF][:19], "%Y-%m-%d %H:%M:%S")
        dur_min = (do_dt - pu_dt).total_seconds() / 60

        if pax <= 0 or pax > 6:
            reasons.append("invalid_passenger_count")
        if dist <= 0 or dist > 100:
            reasons.append("invalid_distance")
        if fare <= 0 or fare > 1000:
            reasons.append("invalid_fare")
        if dur_min <= 0 or dur_min > 240:
            reasons.append("invalid_duration")
        if dist > 0 and (fare / dist) > 100:
            reasons.append("extreme_fare_per_mile")
        if total <= 0:
            reasons.append("invalid_total")
    except (ValueError, IndexError):
        reasons.append("unparseable_record")

    if reasons:
        for r in reasons:
            print(f"{r}\t1")
        print("ANOMALY_TOTAL\t1")
    else:
        print("VALID_TOTAL\t1")
