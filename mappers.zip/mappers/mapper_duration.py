#!/usr/bin/env python3
"""Mapper for analysis (h) Trip Duration Analysis.
Emits: duration_category<TAB>fare,distance,tip,1
"""
import sys, csv
from datetime import datetime

PICKUP, DROPOFF, FARE, DIST, TIP = 1, 2, 10, 4, 13

def bucket(m):
    if m <= 5:
        return "0-5min"
    if m <= 10:
        return "5-10min"
    if m <= 20:
        return "10-20min"
    if m <= 30:
        return "20-30min"
    if m <= 60:
        return "30-60min"
    return "60+min"

reader = csv.reader(sys.stdin)
for row in reader:
    if not row or row[0] == "VendorID":
        continue
    try:
        pu_dt = datetime.strptime(row[PICKUP][:19], "%Y-%m-%d %H:%M:%S")
        do_dt = datetime.strptime(row[DROPOFF][:19], "%Y-%m-%d %H:%M:%S")
        dur_min = (do_dt - pu_dt).total_seconds() / 60
        if dur_min <= 0:
            continue
        fare = float(row[FARE])
        dist = float(row[DIST])
        tip = float(row[TIP])
        print(f"{bucket(dur_min)}\t{fare}\t{dist}\t{tip}\t1")
    except (ValueError, IndexError):
        continue
