#!/usr/bin/env python3
"""
Generic Stage-2 mapper used for every "Top N / Bottom N" job (compulsory
multi-stage MapReduce, Section 9, plus Top10/Bottom10 zones and Top20
routes). It simply re-keys every line from a Stage-1 reducer output with a
single constant key "ALL", forcing every record to land on ONE reducer so
that reducer can sort the full result set and pick the top/bottom N.

Usage in Hadoop Streaming:
  -mapper "python3 mapper_topn.py"
"""
import sys

for line in sys.stdin:
    line = line.rstrip("\n")
    if not line:
        continue
    print(f"ALL\t{line}")
