#!/usr/bin/env python3
"""Mapper for analysis (b) Daily Demand. Emits day name and weekday/weekend flag."""
import sys, csv
from datetime import datetime

PICKUP_DT = 1
DAYS = ["Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"]

reader = csv.reader(sys.stdin)
for row in reader:
    if not row or row[0] == "VendorID":
        continue
    try:
        dt = datetime.strptime(row[PICKUP_DT][:19], "%Y-%m-%d %H:%M:%S")
        day = DAYS[dt.weekday()]
        kind = "Weekend_TOTAL" if dt.weekday() >= 5 else "Weekday_TOTAL"
        print(f"{day}\t1")
        print(f"{kind}\t1")
    except (ValueError, IndexError):
        continue
