#!/usr/bin/env python3
"""Mapper for analysis (e) Payment Method Analysis.
Emits: payment_name<TAB>fare,tip,total,1
"""
import sys, csv

PAYMENT, FARE, TIP, TOTAL = 9, 10, 13, 16
PAYMENT_NAMES = {1: "CreditCard", 2: "Cash", 3: "NoCharge", 4: "Dispute", 5: "Unknown", 6: "VoidedTrip"}

reader = csv.reader(sys.stdin)
for row in reader:
    if not row or row[0] == "VendorID":
        continue
    try:
        pt = int(float(row[PAYMENT]))
        name = PAYMENT_NAMES.get(pt, f"Type{pt}")
        fare = float(row[FARE])
        tip = float(row[TIP])
        total = float(row[TOTAL])
        print(f"{name}\t{fare}\t{tip}\t{total}\t1")
    except (ValueError, IndexError):
        continue
