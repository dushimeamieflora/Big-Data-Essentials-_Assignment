#!/usr/bin/env python3
"""Mapper for analysis (g) Busiest Pickup-Dropoff Routes.
Emits: PU-DO<TAB>fare,total,1
"""
import sys, csv

PU, DO, FARE, TOTAL = 7, 8, 10, 16

reader = csv.reader(sys.stdin)
for row in reader:
    if not row or row[0] == "VendorID":
        continue
    try:
        pu = int(float(row[PU]))
        do = int(float(row[DO]))
        fare = float(row[FARE])
        total = float(row[TOTAL])
        print(f"{pu}-{do}\t{fare}\t{total}\t1")
    except (ValueError, IndexError):
        continue
