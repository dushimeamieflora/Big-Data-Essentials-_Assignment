#!/usr/bin/env python3
"""Mapper for analysis (d) Revenue by Pickup Location.
Emits: PULocationID<TAB>fare,tip,total,distance,1
"""
import sys, csv

PU, FARE, TIP, TOTAL, DIST = 7, 10, 13, 16, 4

reader = csv.reader(sys.stdin)
for row in reader:
    if not row or row[0] == "VendorID":
        continue
    try:
        pu = int(float(row[PU]))
        fare = float(row[FARE])
        tip = float(row[TIP])
        total = float(row[TOTAL])
        dist = float(row[DIST])
        print(f"{pu}\t{fare}\t{tip}\t{total}\t{dist}\t1")
    except (ValueError, IndexError):
        continue
